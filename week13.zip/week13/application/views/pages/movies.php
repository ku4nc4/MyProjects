<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <?php echo $style ?>
  </head>
  <body>
    <?php echo $navbar ?>
    <div class="row" style="margin-top:100px;">
      <div class="col-md-12">
        <?php echo $crud['output'] ?>
      </div>
    </div>
    <?php echo $footer ?>
    <?php echo $script ?>
  </body>
</html>

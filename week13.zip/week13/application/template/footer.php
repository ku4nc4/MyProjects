<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<hr>
<footer class="footer">
	<div class="container">
		<p class="text-muted">Movies Collection - Tim Asisten Laboratorium - 2017 </p>
	</div>
</footer>
﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang('uicolor','ug',{uicolor:{title:'ئىشلەتكۈچى ئارايۈزى رەڭ تاللىغۇچ',preview:'شۇئان ئالدىن كۆزىتىش',config:'بۇ ھەرپ تىزىقىنى config.js ھۆججەتكە چاپلايدۇ',predefined:'ئالدىن بەلگىلەنگەن رەڭلەر'}});

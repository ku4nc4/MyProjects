<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Customer extends CI_Model {

    // public $title;
    // public $content;
    // public $date;

    public function get_all_cust()
    {
        $query = $this->db->get('ms_customer');
        return $query->result();
    }

    public function get_cust_id($id)
    {
        $this->db->where('id',$id);
        $query = $this->db->get('ms_customer');
        return $query->result();
    }

    public function update_cust_id($id,$name)
    {
        $this->db->where('id',$id);
        $this->db->set('name',$name);
        $this->db->update('ms_customer');
    }

    public function delete_cust_id($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('ms_customer');
    }

    public function new_cust($cname)
    {
        $data = array(
            'name' => $cname
        );
        
        $this->db->insert('ms_customer', $data);
    }
}

?>
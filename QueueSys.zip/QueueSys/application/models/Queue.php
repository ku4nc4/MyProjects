<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Queue extends CI_Model {

    // public $title;
    // public $content;
    // public $date;

    public function get_last()
    {
        $this->db->order_by('queueid', 'DESC');
        $query = $this->db->get('queuelog', 1);
        return $query->row();
    }

    public function get_last_cs($id)
    {
        $this->db->order_by('queueid', 'DESC');
        $this->db->where('csid', $id);
        $query = $this->db->get('queuelog', 1);
        return $query->row();
    }

    public function get_null_cs()
    {
        $where = "csid is NULL";
        $this->db->where($where);
        $query = $this->db->get('queuelog');
        return $query->row();
    }
    public function get_null_desc_cs()
    {
        $this->db->order_by('queueid', 'DESC');
        $where = "csid is NULL";
        $this->db->where($where);
        $query = $this->db->get('queuelog');
        return $query->row();
    }

    public function get_not_null_cs()
    {
        $this->db->order_by('queueid', 'DESC');
        $where = "csid is NOT NULL";
        $this->db->where($where);
        $query = $this->db->get('queuelog');
        return $query->row();
    }
    public function get_not_null_cs_last()
    {
        $this->db->order_by('queueid', 'DESC');
        $where = "csid is NOT NULL";
        $this->db->where($where);
        $query = $this->db->get('queuelog',1);
        return $query->row();
    }

    public function insert_entry($id)
    {
            $this->queuestring = $id; // please read the below note
            $this->timequeue  = date('Y-m-d H:i:s');

            $this->db->insert('queuelog', $this);
    }

    public function update_entry($logid,$csid)
    {
            $this->csid = $csid;
            $this->timecall = date('Y-m-d H:i:s');

            $this->db->update('queuelog', $this, array('queueid' => $logid));
            $this->db->reset_query();
    }

    public function update_entry_before($idbefore)
    {
        $this->db->set('timeserve', date('Y-m-d H:i:s'));
        $this->db->where('queueid', $idbefore);
        $this->db->update('queuelog');
        $this->db->reset_query();
    }

}

?>
<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Transaction extends CI_Model {

    // public $title;
    // public $content;
    // public $date;

    public function new_id_trans_header()
    {
        $data = array(
            'id' => NULL
        );
        
        $this->db->insert('transhead', $data);
    }
    public function add_detail($id,$pname)
    {
        $data = array(
            'id_header' => $id,
            'name_item' => $pname
        );
        
        $this->db->insert('transdet', $data);
    }

    public function update_cust($id,$custid,$days)
    {
        $this->db->set('id_cust', $custid);
        $this->db->set('days', $days);
        $this->db->where('id', $id);
        $this->db->update('transhead');
    }

    public function get_detail_id($id)
    {
        $this->db->where('id_header',$id);
        $query = $this->db->get('transdet');
        return $query->result();
    }

    public function get_all_header()
    {
        $this->db->select('*,transhead.id as idtrans');
        $this->db->from('transhead');
        $this->db->join('ms_customer', 'ms_customer.id = transhead.id_cust');
        $query = $this->db->get();
        return $query->result();
    }

    public function get_detail_id_wstatus($idheader)
    {
        $this->db->select('*, transdet.id as detid');
        $this->db->where('id_header',$idheader);
        $this->db->from('transdet');
        $this->db->join('ms_status', 'ms_status.id = transdet.id_status');
        $query = $this->db->get();
        return $query->result();
    }

    public function get_all_status()
    {
        $this->db->select('*');
        $this->db->from('ms_status');
        $query = $this->db->get();
        return $query->result();
    }

    public function update_stat($iddet,$idstat)
    {
        $this->db->set('id_status',$idstat);
        $this->db->where('id',$iddet);
        $this->db->update('transdet');
    }

    public function get_days_id($idheader)
    {
        $this->db->select('*');
        $this->db->where('id',$idheader);
        $this->db->from('transhead');
        $query = $this->db->get();
        return $query->result();
    }
    public function check_status_header($id)
    {
        $this->db->where('id_header',$id);
        $this->db->where('id_status !=',3);
        $query = $this->db->get('transdet',1);
        $res = $query->result();
        if($query->num_rows()>0){
            return 1;
        } else {
            return 0;
        }
    }

}

?>
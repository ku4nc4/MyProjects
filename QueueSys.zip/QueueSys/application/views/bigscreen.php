<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <?php echo $css ?>
    <style media="screen">
    .vertical-center {
        min-height: 100%;
        align-items: center;
        text-align: center;
      }
    </style>

    <title>Hello, world!</title>
  </head>
  <body>
    <div class="container">
    		<div class="row mt-5">
					<h3 class="display-1  w-100">
						<p class="text-center">SAP</p>
					</h3>
    		</div>
				<hr style="border-top: 2px solid rgb(127, 127, 127)">
				<div class="row" style="height:50vh">
					<table class="table text-center">
            <tbody>
              <tr>
                <td rowspan="2" class="align-middle" style="background: #ffc107">
                  <h1 style="font-size:4rem">Antrian pemanggilan</h1>
                  <h3 style="font-size:4rem"><?php echo $notnullcs->queuestring ?> -> <?php echo "CS".$notnullcs->csid ?></h3>
                </td>
                <td>
                  <h1>Customer Service 1</h1>
                  <h3><?php if(isset($cs1)) echo $cs1->queuestring; else echo "Kosong" ?></h3>
                </td>
              </tr>
              <tr>
                <td><h1>Customer Service 2</h1>
                <h3><?php if(isset($cs2)) echo $cs2->queuestring; else echo "Kosong" ?></h3></td>
              </tr>
              <tr>
                <td rowspan="2" class="align-middle"><h1>Antrian berikutnya</h1>
                <h3><?php if(isset($nullcs)) echo $nullcs->queuestring; else echo "Belum ada" ?></h3></td>
                <td><h1>Customer Service 3</h1>
                <h3><?php if(isset($cs3)) echo $cs3->queuestring; else echo "Kosong" ?></h3></td>
              </tr>
              <tr>
                <td><h1>Customer Service 4</h1>
                <h3><?php if(isset($cs4)) echo $cs4->queuestring; else echo "Kosong" ?></h3></td>
              </tr>

            </tbody>
          </table>
          </div>
				</div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <?php echo $js ?>
  </body>
</html>

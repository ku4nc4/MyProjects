<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
	<!DOCTYPE html>
	<!doctype html>
	<html lang="en">

	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Bootstrap CSS -->
		<?php echo $css ?>
		<style media="screen">
			.vertical-center {
				min-height: 100%;
				align-items: center;
				text-align: center;
			}

		</style>

		<title>Hello, world!</title>
	</head>

	<body>
		<div class="container">
			<div class="row">
				<h1 class="display-1 text-center w-100">Dashboard</h1>
			</div>
			<div class="row">
                <div class="col-md-4"><a href="<?php echo base_url('index.php/status/crudcust') ?>"><button class="btn btn-primary">Customer Data</button></a></div>
                <div class="col-md-4"><a href="<?php echo base_url('index.php/status/newtrans') ?>"><button class="btn btn-primary">New Transaction</button></a></div>
                <div class="col-md-4"><a href="<?php echo base_url('index.php/status/updatestat') ?>"><button class="btn btn-primary">Update Status</button></a></div>
            </div>
		</div>
	</body>

	</html>
	<?php echo $js ?>
	<script>
		$(document).ready(function () {
			$('#custtable').DataTable();
		});

	</script>

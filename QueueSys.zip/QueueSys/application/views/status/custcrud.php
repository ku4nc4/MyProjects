<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
	<!DOCTYPE html>
	<!doctype html>
	<html lang="en">

	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Bootstrap CSS -->
		<?php echo $css ?>
		<style media="screen">
			.vertical-center {
				min-height: 100%;
				align-items: center;
				text-align: center;
			}

		</style>

		<title>Hello, world!</title>
	</head>

	<body>
		<div class="container">
			<div class="row">
				<h1 class="display-1 text-center w-100">Customer CRUD</h1>
			</div>
			<div class="row">
				<p class="text-right w-100">
					<a href="<?php echo base_url('index.php/status/newcust') ?>">
						<button class="btn btn-primary">New</button>
					</a>
				</p>

				<table class="table" id="custtable">
					<thead>
						<tr>
							<th>Id Customer</th>
							<th>Nama Customer</th>
							<th>Actions</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ($cust as $row) {
                ?>
						<tr>
							<td>
								<?php echo $row->id ?>
							</td>
							<td>
								<?php echo $row->name ?>
							</td>
							<td>
								<a href="<?php echo base_url('index.php/status/editcust/'.$row->id) ?>"><button class="btn btn-primary">Edit</button></a>
								<a href="<?php echo base_url('index.php/status/delcust/'.$row->id) ?>"><button class="btn btn-primary">Delete</button></a>
							</td>
						</tr>
						<?php
              } ?>
					</tbody>
				</table>
			</div>
			<a href="<?php echo base_url('index.php/status') ?>"><button class="btn btn-danger">Back</button></a>
		</div>
		
	</body>

	</html>
	<?php echo $js ?>
	<script>
		$(document).ready(function () {
			$('#custtable').DataTable();
		});

	</script>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
	<!DOCTYPE html>
	<!doctype html>
	<html lang="en">

	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Bootstrap CSS -->
		<?php echo $css ?>
		<style media="screen">
			.vertical-center {
				min-height: 100%;
				align-items: center;
				text-align: center;
			}

		</style>

		<title>Hello, world!</title>
	</head>

	<body>
		<div class="container">
			<div class="row">
				<h1 class="display-1 text-center w-100">List Detail Proses</h1>
			</div>
            <div class="row">
                <h4 class="display-4 text-center w-100">Order no <?php echo $idheader ?></h4>
            </div>
			<div class="row">
                <?php echo form_open('status/updatedet',"style='width:100%'") ?>
                <table class="table" id="listorder">
                    <thead>
                        <tr>
                            <th>Nama Item</th>
                            <th>Status</th>
                            <!-- <th>Status id</th> -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            foreach($alldet as $rows){
                                ?>
                                    <tr style='background:<?php if($rows->id_status == 1) echo 'orange'; else if($rows->id_status == 2) echo 'yellow';?>'>
                                        <td style='width:70%'><?php echo $rows->name_item ?></td>
                                        <td>
                                            <select class="form-control" name="idstat<?php echo $rows->detid ?>" id="">
                                            <?php
                                                foreach ($allstat as $stat) {
                                                    ?>
                                                    <option value="<?php echo $stat->id ?>" <?php if($stat->id == $rows->id_status) echo 'selected' ?>><?php echo $stat->name ?></option>
                                                    <?php
                                                }
                                            ?>
                                            </select>
                                        </td>
                                        <!-- <td><?php echo $rows->id_status ?></td> -->
                                        <!-- <td><a href="<?php echo base_url('index.php/status/detail/'.$rows->idtrans) ?>"><button>Here</button></a></td> -->
                                    </tr>
                                <?php
                            }
                        ?>
                    </tbody>
                </table>
                <input type="hidden" name="idhead" value="<?php echo $idheader ?>">
                <div class="row mt-3">
                    <p class="w-100 text-right">
                        <a href="<?php echo base_url('index.php/status/index') ?>"><button type="submit" class="btn btn-danger">Cancel</button></a>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </p>
                </div>
                
                <?php echo form_close() ?>
            </div>
		</div>
	</body>

	</html>
	<?php echo $js ?>
	<script>
		$(document).ready(function () {
			$('#listorder').DataTable();
		});

	</script>

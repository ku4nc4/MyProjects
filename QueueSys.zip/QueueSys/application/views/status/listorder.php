<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
	<!DOCTYPE html>
	<!doctype html>
	<html lang="en">

	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Bootstrap CSS -->
		<?php echo $css ?>
		<style media="screen">
			.vertical-center {
				min-height: 100%;
				align-items: center;
				text-align: center;
			}

		</style>

		<title>Hello, world!</title>
	</head>

	<body>
		<div class="container">
			<div class="row">
				<h1 class="display-1 text-center w-100">List Order Proses</h1>
			</div>
			<div class="row">
                <table class="table" id="listorder">
                    <thead>
                        <tr>
                            <th>Nomor Order</th>
                            <th>Nama Customer</th>
                            <th>Tanggal Order</th>
                            <th>Lihat Detail</th>
                            <th>Hari Selesai</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            foreach($allhead as $rows){
                                ?>
                                    <tr>
                                        <td><?php echo $rows->idtrans ?></td>
                                        <td><?php echo $rows->name ?></td>
                                        <td><?php echo $rows->time_start ?></td>
                                        <td><a href="<?php echo base_url('index.php/status/detail/'.$rows->idtrans) ?>"><button>Here</button></a></td>
                                        <td>
                                            <?php echo $rows->days ?>
                                        </td>
                                    </tr>
                                <?php
                            }
                        ?>
                    </tbody>
                </table>
            </div>
            <div class="row">
                <a href="<?php echo base_url('index.php/status') ?>"><button class="btn btn-danger">Back</button></a>
            </div>
		</div>
	</body>

	</html>
	<?php echo $js ?>
	<script>
		$(document).ready(function () {
			$('#listorder').DataTable();
		});

	</script>

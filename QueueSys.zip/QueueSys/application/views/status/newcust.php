<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
	<!DOCTYPE html>
	<!doctype html>
	<html lang="en">

	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Bootstrap CSS -->
		<?php echo $css ?>
		<style media="screen">
			.vertical-center {
				min-height: 100%;
				align-items: center;
				text-align: center;
			}

		</style>

		<title>Hello, world!</title>
	</head>

	<body>
		<div class="container">
			<div class="row">
				<h1 class="display-1 text-center w-100">New Customer</h1>
			</div>
			<?php echo form_open('status/newcust_b') ?>
				<div class="form-group">
					<label for="exampleInputEmail1">Name</label>
					<input type="text" class="form-control" name="cname" placeholder="Enter Customer Name">
					<!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
				</div>
				<button type="submit" class="btn btn-primary">Submit</button>
                <?php echo form_close() ?>
		</div>
	</body>

	</html>
	<?php echo $js ?>
	<script>
		$(document).ready(function () {
			$('#custtable').DataTable();
		});

	</script>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
	<!DOCTYPE html>
	<!doctype html>
	<html lang="en">

	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Bootstrap CSS -->
		<?php echo $css ?>
		<style media="screen">
			.vertical-center {
				min-height: 100%;
				align-items: center;
				text-align: center;
			}

		</style>

		<title>Hello, world!</title>
	</head>

	<body>
		<div class="container">
			<div class="row">
				<h1 class="display-1 text-center w-100">New Transaction</h1>
			</div>
            <div class="row">
                <h4>No Order : <?php echo $insid ?></h4>
            </div>
			<?php echo form_open('status/newtrans') ?>
			<div class="row">
				<select class="form-control" name="cust" id="">
					<option selected="true" value="" disabled>Select Customer</option>
					<?php foreach ($cust as $row) { ?>
						<option value="<?php echo $row->id ?>">
							<?php echo $row->name ?>
						</option>
					<?php } ?>
				</select>
			</div>
			<div class="row">
				<p>Perkiraan Hari Selesai : </p>
				<input class="form-control" type="number" name="days" id="">
			</div>
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $counter = 1;
                        foreach ($details as $detail) {
                            ?>
                                <tr>
                                    <td><?php echo $counter ?></td>
                                    <td><?php echo $detail->name_item ?></td>
                                </tr>
                            <?php
                            $counter++;
                        }
                    ?>
                </tbody>
            </table>
			<div class="form-group">
				<a href=""><button type="button" class="btn btn-default" onclick="selectValue('<?php echo $this->session->id ?>')">Add Item</button></a>
			</div>
			<a href="<?php echo base_url('index.php/welcome/printqr/'.$this->session->id) ?>"><button type="button" class="btn btn-btn-info">Print</button></a>
			<button type="submit" class="btn btn-primary">Submit</button>
			<a href="<?php echo base_url('index.php/status') ?>"><button type="button" class="btn btn-danger">Back</button></a>
			<?php echo form_close() ?>
		</div>
	</body>

	</html>
	<?php echo $js ?>
	<script>
		$(document).ready(function () {
			$('#custtable').DataTable();
		});
        
        
	</script>

    <script>
		function selectValue(id) {
			// open popup window and pass field id
			window.open('<?php echo base_url();?>index.php/status/additem/<?php echo $this->session->id ?>?id='+ encodeURIComponent(id), 'popuppage',
				'width=400,toolbar=1,resizable=1,scrollbars=yes,height=400,top=100,left=100');
		}
        var counter = 0;
		function updateValue(id, value) {
			// this gets called from the popup window and updates the field with a new value
            if (counter == 0) {
                document.getElementById(id).value = value;
            } else {
                document.getElementById(id).value += ", "+value;
            }
			counter++;
		}

	</script>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
	<!DOCTYPE html>
	<!doctype html>
	<html lang="en">

	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Bootstrap CSS -->
		<?php echo $css ?>
		<style media="screen">
			.vertical-center {
				min-height: 100%;
				align-items: center;
				text-align: center;
			}

		</style>

		<title>Hello, world!</title>
	</head>

	<body>
		<div class="container">
			<div class="row mt-5">
				<h1 class="display-1  w-100">
					<p class="text-center">SAP</p>
					<p style="font-size:2rem">CS number :
						<?php echo $id; ?>
					</p>
				</h1>
			</div>
			<hr style="border-top: 2px solid rgb(127, 127, 127)">
			<div class="row" style="height:50vh">
				<div class="col-md-6">
					<?php echo form_open('welcome/csnext','style="height:100%; width:100%"') ?>
					<input type="hidden" name="csid" value="<?php echo $id ?>">
          <?php 
            $idbefore = 0;
            if(isset($lastrec)){
              foreach ($lastrec as $key => $value) {
                if($key == "queueid"){$idbefore = $value;} 
              }
            }
          ?>
					<input type="hidden" name="idbefore" value="<?php echo $idbefore ?>">
					<button type="submit" name="button" class="btn btn-warning" style="height:100%; width:100%">
						<h1 style="font-size:2.8rem">PANGGIL CUSTOMER</h1>
					</button>
					</form>
				</div>
				<div class="col-md-6 text-center">
					<div style="height:40%;">

					</div>
					<div style="height:20%">
						<h1>Antrian Yang Anda Layani Saat Ini</h1>

						<h1>
              <?php 
                if(isset($lastrec)){
                  foreach ($lastrec as $key => $value) {
                    if($key == "queuestring"){echo $value;} 
                  }
                }else {
                  echo "Anda Belum melayani";
                }
              ?>
						</h1>
					</div>
					<div style="height:40%;">

					</div>
				</div>
			</div>
		</div>

		<!-- Optional JavaScript -->
		<!-- jQuery first, then Popper.js, then Bootstrap JS -->
		<?php echo $js ?>
	</body>

	</html>

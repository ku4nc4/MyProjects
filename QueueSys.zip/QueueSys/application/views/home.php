<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <?php echo $css ?>

    <title>Hello, world!</title>
  </head>
  <body>
    <div class="container">
    		<div class="row mt-5">
					<h1 class="display-1  w-100">
						<p class="text-center">SAP</p>
					</h1>
    		</div>
				<hr style="border-top: 2px solid rgb(127, 127, 127)">
				<div class="row" style="height:50vh">
					<div class="col-md-3">

					</div>
					<div class="col-md-6">
            <a href="<?php echo base_url('index.php/welcome/printnew') ?>">
              <button type="button" name="button" class="btn btn-warning" style="height:100%; width:100%"><h1 style="font-size:2.8rem">AMBIL NOMOR</h1></button>
            </a>	
					</div>
					<div class="col-md-3">

					</div>
				</div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <?php echo $js ?>
  </body>
</html>

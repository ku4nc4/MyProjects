<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require 'E:\laragon\www\QueueSys\vendor\autoload.php';
use Mike42\Escpos\PrintConnectors\FilePrintConnector;
use Mike42\Escpos\EscposImage;
use Mike42\Escpos\PrintConnectors\WindowsPrintConnector;
use Mike42\Escpos\Printer;

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$data['css'] = $this->load->view('includes/css',NULL,TRUE);
		$data['js'] = $this->load->view('includes/js',NULL,TRUE);
		$this->load->view('home',$data);
		
	}
	public function cs($id)
	{
		$this->load->model('queue');
		$data['id'] = $id;
		$data['lastrec'] = $this->queue->get_last_cs($id);
		$data['css'] = $this->load->view('includes/css',NULL,TRUE);
		$data['js'] = $this->load->view('includes/js',NULL,TRUE);
		$this->load->view('csscreen',$data);
	}
	public function bigscreen()
	{
		$this->load->model('queue');
		$data['notnullcs'] = $this->queue->get_not_null_cs();
		$data['nullcs'] = $this->queue->get_null_cs();
		$data['cs1'] = $this->queue->get_last_cs(1);
		$data['cs2'] = $this->queue->get_last_cs(2);
		$data['cs3'] = $this->queue->get_last_cs(3);
		$data['css'] = $this->load->view('includes/css',NULL,TRUE);
		$data['js'] = $this->load->view('includes/js',NULL,TRUE);
		$this->load->view('bigscreen',$data);
	}

	public function printnew(Type $var = null)
	{
		$this->load->model('queue');
		$lastrec = $this->queue->get_last();
		$lastqueuenum = "";
		foreach ($lastrec as $key => $value) {
			if($key=="queueid"){
				$lastqueueid = $value;
			}
			if($key=="queuestring"){
				$lastqueuenum = $value;
			}
		}
		$nam = substr($lastqueuenum,1,4);
		$nam = (int)$nam;
		$nam++;
		while(strlen($nam)!=4){
			$nam = "0".$nam;
		}
		$nam = "A".$nam;
		echo $nam;
		$this->queue->insert_entry($nam);
		$lastserve = $this->queue->get_not_null_cs_last();
		
		try {
			$connector = new WindowsPrintConnector("ZJ-581");
			$printer = new Printer($connector);
			$printer -> setJustification(1);
			$printer -> setTextSize(1, 2);
			$printer -> text("SAM DIGITAL CREATIVE\n");
			$printer -> setTextSize(2, 2);
			$printer -> text("$nam\n");
			$printer -> setTextSize(1, 1);
			$printer -> text("Antrian sekarang : $lastserve->queuestring\n");
			$printer -> feed();
			$printer -> feed();
			$printer -> cut();
			$printer -> close();
		} catch(Exception $e) {
			echo "Couldn't print to this printer: " . $e -> getMessage() . "\n";
		}
		
		redirect('welcome');
	}

	public function csnext()
	{
		$id = $this->input->post('csid');
		$idbefore = $this->input->post('idbefore');
		$this->load->model('queue');
		$res = $this->queue->get_null_cs();
		$queuenum = "";
		foreach ($res as $key => $value) {
			if($key == "queueid"){
				$queuenum = $value;
			}
		}
		echo $idbefore." ".$queuenum;
		$this->queue->update_entry($queuenum,$id);
		$this->queue->update_entry_before($idbefore);
		redirect("welcome/cs/$id");
	}

	public function printqr($idheader)
	{
		include('E:\laragon\www\QueueSys\assets\qrlib.php');
		QRcode::png('http://localhost/QueueSys/index.php/status/custview/'.$idheader,'E:/laragon/www/QueueSys/assets/qrcodes/'.$idheader.'.png',QR_ECLEVEL_L, 3);
		
		$img = EscposImage::load('E:/laragon/www/QueueSys/assets/qrcodes/'.$idheader.'.png');
		try {
			$connector = new WindowsPrintConnector("ZJ-581");
			$printer = new Printer($connector);
			$printer -> setJustification(1);
			$printer -> bitImage($img);
			$printer -> feed();
			$printer -> feed();
			$printer -> cut();
			$printer -> close();
			redirect('status/newtrans');
		} catch(Exception $e) {
			echo "Couldn't print to this printer: " . $e -> getMessage() . "\n";
		}
	}
}

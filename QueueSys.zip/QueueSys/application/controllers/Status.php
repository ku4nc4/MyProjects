<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require 'E:\laragon\www\QueueSys\vendor\autoload.php';
use Mike42\Escpos\PrintConnectors\FilePrintConnector;
use Mike42\Escpos\EscposImage;
use Mike42\Escpos\PrintConnectors\WindowsPrintConnector;
use Mike42\Escpos\Printer;

class Status extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function index()
	{
		$data['css'] = $this->load->view('includes/css',NULL,TRUE);
		$data['js'] = $this->load->view('includes/js',NULL,TRUE);
		$this->load->view('status/index',$data);
	}

	public function crudcust()
	{
		$data['css'] = $this->load->view('includes/css',NULL,TRUE);
		$data['js'] = $this->load->view('includes/js',NULL,TRUE);
		$this->load->model('customer');
		$data['cust'] = $this->customer->get_all_cust();
		// var_dump($data['cust']);
		$this->load->view('status/custcrud',$data);
		
	}
	public function newcust()
	{
		$data['css'] = $this->load->view('includes/css',NULL,TRUE);
		$data['js'] = $this->load->view('includes/js',NULL,TRUE);
		$this->load->model('customer');
		
		$this->load->view('status/newcust',$data);
		
	}

	public function editcust($id)
	{
		$data['css'] = $this->load->view('includes/css',NULL,TRUE);
		$data['js'] = $this->load->view('includes/js',NULL,TRUE);
		$this->load->model('customer');
		$data['cname'] = $this->customer->get_cust_id($id);
		$this->load->view('status/editcust',$data);
		
	}

	public function newcust_b()
	{
		$this->load->model('customer');
		$cname = $this->input->post('cname');
		$this->customer->new_cust($cname);
		redirect('status/crudcust');
	}

	public function editcust_b($id)
	{
		$this->load->model('customer');
		$cname = $this->input->post('cname');
		$this->customer->update_cust_id($id,$cname);
		redirect('status/crudcust');
	}

	public function delcust($id)
	{
		$this->load->model('customer');
		$this->customer->delete_cust_id($id);
		redirect('status/crudcust');
	}



	public function newtrans()
	{
		$this->load->model('transaction');
		if($this->input->post('cust') || $this->input->post('days')){
			$this->transaction->update_cust($this->session->id,$this->input->post('cust'),$this->input->post('days'));
			$this->session->unset_userdata('id');
			redirect('status');
		}
		if(!$this->session->has_userdata('id')){
			$this->transaction->new_id_trans_header();
			$data['insid'] = $this->db->insert_id();
			$this->session->set_userdata('id',$data['insid']);
		} else {
			$data['insid'] = $this->session->id;
		}
		$data['css'] = $this->load->view('includes/css',NULL,TRUE);
		$data['js'] = $this->load->view('includes/js',NULL,TRUE);
		$data['details'] = $this->transaction->get_detail_id($this->session->id);
		$this->load->model('customer');
		$data['cust'] = $this->customer->get_all_cust();
		$this->load->view('status/newtrans',$data);
	}
	public function additem($transid)
	{
		$this->load->model('transaction');
		if(!$this->input->post('pname')){
			
			$data['css'] = $this->load->view('includes/css',NULL,TRUE);
			$data['js'] = $this->load->view('includes/js',NULL,TRUE);
			$this->load->view('status/additem',$data);
		}else {
			$pname = $this->input->post('pname');
			$this->transaction->add_detail($transid,$pname);
			redirect('status/additem/'.$transid);
		}
		
		
	}

	public function updatecust()
	{
		$this->load->model('transaction');
		if(!$this->session->has_userdata('id')){
			$this->transaction->new_id_trans_header();
			$data['insid'] = $this->db->insert_id();
			$this->session->set_userdata('id',$data['insid']);
		} else {
			$data['insid'] = $this->session->id;
		}
		$data['css'] = $this->load->view('includes/css',NULL,TRUE);
		$data['js'] = $this->load->view('includes/js',NULL,TRUE);
		$this->load->model('customer');
		$data['cust'] = $this->customer->get_all_cust();
		$this->load->view('status/newtrans',$data);
	}

	public function updatestat()
	{
		$this->load->model('transaction');
		$data['allhead'] = $this->transaction->get_all_header();
		$data['css'] = $this->load->view('includes/css',NULL,TRUE);
		$data['js'] = $this->load->view('includes/js',NULL,TRUE);
		$this->load->view('status/listorder',$data);
	}

	public function detail($idheader)
	{
		$this->load->model('transaction');
		$data['idheader'] = $idheader;
		$data['alldet'] = $this->transaction->get_detail_id_wstatus($idheader);
		$data['allstat'] = $this->transaction->get_all_status();
		$data['css'] = $this->load->view('includes/css',NULL,TRUE);
		$data['js'] = $this->load->view('includes/js',NULL,TRUE);
		$this->load->view('status/listdetail',$data);
	}

	public function updatedet()
	{
		$this->load->model('transaction');
		$idheader = $this->input->post('idhead');
		$dets = $this->transaction->get_detail_id($idheader);

		foreach ($dets as $det) {
			$idstat = $this->input->post('idstat'.$det->id);
			$this->transaction->update_stat($det->id,$idstat);
		}
		redirect('status');
	}

	public function custview($idheader)
	{
		$this->load->model('transaction');
		$data['idheader'] = $idheader;
		$data['alldet'] = $this->transaction->get_detail_id_wstatus($idheader);
		$data['allstat'] = $this->transaction->get_all_status();
		$data['css'] = $this->load->view('includes/css',NULL,TRUE);
		$data['js'] = $this->load->view('includes/js',NULL,TRUE);
		$this->load->view('status/custview',$data);
	}
}

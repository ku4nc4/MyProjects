<script src="<?php echo base_url('assets/js/jquery-1.12.4.js') ?>" charset="utf-8"></script>
<script src="<?php echo base_url('assets/js/jquery.dataTables.min.js') ?>" charset="utf-8"></script>
<script src="<?php echo base_url('assets/js/dataTables.bootstrap.min.js') ?>" charset="utf-8"></script>

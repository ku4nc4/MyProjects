<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Northwind Trader[IF635 UMN]</a>
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li class="active"><a href="#">Product List</a></li>
    </ul>
  </div>
</nav>

<?php
defined("BASEPATH") or exit("no");

class Test extends CI_Controller{
  public function index(){
    echo "ini index";
  }
}
 ?>

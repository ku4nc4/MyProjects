<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<footer class="footer navbar-fixed-bottom" style="border-top: 1px solid;">
	<div class="container">
		<p class="text-muted"> WebDB Cinemaks - Education Purpose Only - 2017 </p>
	</div>
</footer>
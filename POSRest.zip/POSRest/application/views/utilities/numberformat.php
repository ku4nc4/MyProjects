<script type="text/javascript">
  $(document).ready(function(){
    $('.money').each(function(){
        var before = $(this).html();
        var after = numeral(before).format('0,0');
        $(this).html(after);
      });
  });
</script>

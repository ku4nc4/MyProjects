<div class="container">
	<h1 class="display-1 mb-5">Checkout</h1>
	<div class="row" style="height:60vh;overflow-y:scroll">
		<table class="table">
			<thead>
				<tr>
					<th width=60%>Pesanan</th>
					<th idth=10%>Quantity</th>
					<th>Harga</th>
				</tr>
			</thead>
			<tbody>
				<?php $tprice = 0;?>
				<?php foreach ($cartdata as $cart): ?>
					<tr>
						<td><?php echo $cart['name'] ?></td>
						<td><?php echo $cart['qty'] ?></td>
						<td class="money"><?php echo $cart['price'] ?></td>
					</tr>
					<?php $tprice += $cart['price']; ?>
				<?php endforeach; ?>
				<tr>
					<td></td>
					<td></td>
					<td class="money"><?php echo $tprice ?></td>
				</tr>
			</tbody>
		</table>
	</div>

	<div class="row">
		<a href="<?php echo base_url('menu/sendtokitchen') ?>"><button type="button" class="btn btn-danger mr-1">Send it to the kitchen</button></a>
		<a href="<?php echo base_url('menu') ?>"><button type="button" name="button" class="btn btn-info">Back to Menu</button></a>
	</div>
</div>

<style media="screen">
  .cart{
    position: fixed;
    bottom: 5rem;
    right: 5rem;
  }

  .menulist{
    position: fixed;
    bottom: 8rem;
    right: 5rem;
    width: 18rem;
    height: 400px;
    z-index: 9999;
  }

  @media only screen and (max-width: 500px) {
    .menulist{
      position: fixed;
      top: 50%;
      left: 50%;
      margin-top: -35vh; /* Negative half of height. */
      margin-left: -45vw; /* Negative half of width. */
      width: 90vw;
      overflow-y: auto;
      height: 70vh;
    }

    .cart{
      position: fixed;
      bottom: 2rem;
      right: 2rem;
    }
  }
</style>
<div class="menulist">
  <div class="card text-white bg-dark mb-3">
    <div class="card-body">
      Your orders :
      <hr style="border-color:white">
      <!-- List of selected menu here -->
      <div style="height:180px;overflow-y:auto;background:#fbfbfb;color:#2e2532;border-radius:10px">
        <?php foreach ($cartdata as $items): ?>
          <p class="m-2"><?php echo $items['name'] ?> - <?php echo $items['qty'] ?>
            <a href="<?php echo base_url("menu/deletecartid/".$items['rowid']) ?>">
              <button type="button" class="btn btn-info" name="button">Delete</button>
            </a>
          </p>
          <hr>
        <?php endforeach; ?>
      </div>

      <hr style="border-color:white">
      <div class="row">
        <a href="<?php echo base_url('menu/checkout') ?>"><button class="btn btn-warning m-2" type="button" name="button">Order Now</button></a>
        <?php echo form_open('menu/emptycart') ?>
        <button type="submit" class="btn btn-danger m-2" name="action" value="clear">Clear Cart</button>
        <?php echo form_close() ?>
      </div>
    </div>
  </div>
</div>
<div class="cart">
        <?php
          $image_properties = array(
            'src'   => base_url('resource/img/cardbutton.png'),
            'alt'   => 'Me, demonstrating how to eat 4 slices of pizza at one time',
            'title' => 'That was quite a night',
            'rel'   => 'lightbox',
            'style' => 'width:100%;'
          );
           ?>
        <a id="triggermenulist"><?php echo img($image_properties) ?></a>
</div>
<script src="<?php echo base_url('resource/js/jquery-3.2.1.min.js') ?>" charset="utf-8"></script>
<script type="text/javascript">
  $('.menulist').hide();
  $( "#triggermenulist" ).click(function() {
      $( ".menulist" ).toggle();
  });
</script>

<?php echo $ip ?>
<?php if (isset($fail)): ?>
  <script type="text/javascript">
  alert("<?php echo $error ?>");
  </script>
<?php endif; ?>
<div class="container">
  <div class="row">
    <div class="col-md-9">
      <h1 class="display-4">Menu</h1>
    </div>
    <div class="col-md-3 text-right">
      <a href="<?php echo base_url('menu/bill') ?>"><button type="button" class="btn btn-primary">Get Bill</button></a>
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <div class="row">
        <!-- Menu start here /loops -->
        <?php foreach ($menus as $menu): ?>
          <?php $cardclass = "card " ?>
          <?php if($menu['pk_id_menu_type']==1){
            $cardclass .= "text-white bg-danger";
          } elseif($menu['pk_id_menu_type']==2){
            $cardclass .= "text-white bg-info";
          } else{
            $cardclass .= "bg-light";
          } ?>
          <div class="col-md-4 mb-3 ">
            <?php echo form_open('menu/addcart') ?>
            <div class="<?php echo $cardclass ?>">
              <?php
              $image_properties = array(
                'src'   => base_url('resource/img/'.$menu['std_imgsrc']),
                'alt'   => 'Me, demonstrating how to eat 4 slices of pizza at one time',
                'class' => 'card-img-top',
                'title' => 'That was quite a night',
                'rel'   => 'lightbox',
                'style' => 'object-fit: cover; height:180px'
              );
              ?>
              <?php echo img($image_properties) ?>
              <div class="card-body">
                <h4 class="card-title"><?php echo $menu['std_nama_menu'] ?></h4>
                <input type="hidden" name="menuname" value="<?php echo $menu['std_nama_menu'] ?>">
                <input type="hidden" name="menuid" value="<?php echo $menu['pk_id_menu'] ?>">
                <input type="hidden" name="price" value="<?php echo $menu['std_harga_menu'] ?>">
                <p class="card-text" style="height:80px;overflow-y:auto"><?php echo $menu['std_deskripsi'] ?></p>
                <p class="card-text money"><?php echo $menu['std_harga_menu'] ?></p>
                <div class="row">
                  <div class="col-md-4">
                    <input class="form-control" type="number" name="qty" value="0" class="col-md-3">
                  </div>
                  <button type="submit" class="btn btn-primary" class="col-md-8">Order</button>
                </div>
              </div>
            </div>
            <?php echo form_close(); ?>
          </div>
        <?php endforeach; ?>

        <!-- Menu stop here /stopLoops -->
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
var request;
var old = "";

$(document).ready(function(){
  function ping(){
    request = $.ajax({
      url: "<?php echo base_url('menu') ?>",
      type: "post"
    });
    request.done(function(response){
      if (old == "") {
        old = response;
      } else if(old != response) {
        location.reload();
      }
    });

  }
  setInterval(function(){
    ping();
  },1000);
});
</script>


	<div class="container">
    <h1 class="display-1">Bill Overview</h1>
    <div class="row" style="height:70vh;overflow-y:scroll">
      <table class="table">
        <thead>
          <tr>
            <th width=60%>Pesanan</th>
            <th idth=10%>Quantity</th>
            <th>Harga</th>
          </tr>
        </thead>
        <tbody>
					<?php $tharga = 0 ?>
						<?php foreach ($billitem as $item): ?>
							<tr>
								<td><?php echo $item['std_nama_menu'] ?></td>
								<td><?php echo $item['std_qty'] ?></td>
								<td class="money"><?php echo $item['std_harga_menu'] ?></td>
							</tr>
							<?php $tharga += $item['std_harga_menu'] ?>
						<?php endforeach; ?>
						<tr>
							<td></td>
							<td></td>
							<td class="money"><?php echo $tharga ?></td>
						</tr>
        </tbody>
      </table>
    </div>
		<div class="row">
			<a href="<?php echo base_url('menu/paybills') ?>"><button type="button" class="btn btn-primary mr-1">Pay Bills</button></a>
			<a href="<?php echo base_url('menu') ?>"><button type="button" class="btn btn-warning">Back to Menu</button></a>
		</div>
  </div>

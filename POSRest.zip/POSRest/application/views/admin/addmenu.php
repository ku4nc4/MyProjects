<style media="screen">
	.cropit-preview {
		/* You can specify preview size in CSS */
		width: 800px;
		height: 600px;
		border-style: solid;
		border-width: 2px;
	}
</style>
<div class="container mt-3">
	<div class="row">
		<div class="col-md-12">
			<?php echo form_open_multipart('admin/addmenuprocess') ?>
			<h1 class="display-1">Add Menu</h1>
				<div class="form-group">
					<label for="exampleFormControlFile1">Upload Foto Menu</label>
					<input type="file" class="form-control-file" id="menuimg" name="menuimg">
				</div>
			<div class="form-group row">
				<label for="example-text-input" class="col-2 col-form-label">Nama Menu</label>
				<div class="col-10">
					<input class="form-control" type="text" value="" id="menuname" name="mname">
				</div>
			</div>
			<div class="form-group">
				<label for="exampleFormControlSelect1">Food Type</label>
				<select class="form-control" id="tipemakanan" name="mtype">

					<?php foreach ($menutype as $tipe): ?>
							<option value="<?php echo $tipe['pk_id_menu_type'] ?>"><?php echo $tipe['std_nama_menu_type'] ?></option>
					<?php endforeach; ?>
        </select>
			</div>
			<!-- This wraps the whole cropper -->
			<center>

			</center>
			<div class="form-group">
				<label for="exampleTextarea">Deskripsi</label>
				<textarea class="form-control" id="menudesc" rows="3" name="mdesc"></textarea>
			</div>
			<div class="form-group row">
				<label for="example-text-input" class="col-2 col-form-label">Harga</label>
				<div class="col-10">
					<input class="form-control" type="text" value="" id="menuprice" name="mprice">
				</div>
			</div>

			<button type="submit" id="postbut" class="btn btn-primary" style="width: 100%">Tambah Menu</button>
			<?php echo form_close() ?>
		</div>
	</div>
</div>
<script type="text/javascript">
	// In the demos I'm passing in an imageState option
	// so it renders an image by default:
	// $('#image-cropper').cropit({ imageState: { src: { imageSrc } } });

	// Exporting cropped image

	new Cleave('#menuprice', {
		numeral: true,
		prefix: 'IDR'
	});
</script>

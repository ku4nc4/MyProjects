<?php
echo $uname;
?>

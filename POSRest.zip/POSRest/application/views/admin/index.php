<style media="screen">
/*
* Base structure
*/

/* Move down content because we have a fixed navbar that is 3.5rem tall */
body {
padding-top: 3.5rem;
}

/*
* Typography
*/

h1 {
padding-bottom: 9px;
margin-bottom: 20px;
border-bottom: 1px solid #eee;
}

/*
* Sidebar
*/

.sidebar {
position: fixed;
top: 51px;
bottom: 0;
left: 0;
z-index: 1000;
padding: 20px 0;
overflow-x: hidden;
overflow-y: auto; /* Scrollable contents if viewport is shorter than content. */
border-right: 1px solid #eee;
}

.sidebar .nav {
margin-bottom: 20px;
}

.sidebar .nav-item {
width: 100%;
}

.sidebar .nav-item + .nav-item {
margin-left: 0;
}

.sidebar .nav-link {
border-radius: 0;
}

/*
* Dashboard
*/

/* Placeholders */
.placeholders {
padding-bottom: 3rem;
}

.placeholder img {
padding-top: 1.5rem;
padding-bottom: 1.5rem;
}

</style>
<header>
      <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
        <a class="navbar-brand" href="#">Dashboard</a>
        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="<?php echo base_url('admin') ?>">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url('kitchen') ?>">Kitchen</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url('waitress') ?>">Waiter</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url('admin/cashier') ?>">Cashier</a>
            </li>
          </ul>
          <ul class="navbar-nav">
            <li class="nav-link">
              <a href="<?php echo base_url('admin/logout') ?>" class="nav-link">Logout</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>

    <div class="container-fluid">
      <div class="row">
        <nav class="col-sm-3 col-md-2 d-none d-sm-block bg-light sidebar">
          <ul class="nav nav-pills flex-column">
            <li class="nav-item">
              <a class="nav-link active" href="#">Overview <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Reports</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Analytics</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Export</a>
            </li>
          </ul>

          <ul class="nav nav-pills flex-column">
            <li class="nav-item">
              <a class="nav-link" href="#">Nav item</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Nav item again</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">One more nav</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Another nav item</a>
            </li>
          </ul>

          <ul class="nav nav-pills flex-column">
            <li class="nav-item">
              <a class="nav-link" href="#">Nav item again</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">One more nav</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Another nav item</a>
            </li>
          </ul>
        </nav>

        <main role="main" class="col-sm-9 ml-sm-auto col-md-10 pt-3">
          <h1 class="mt-1">Dashboard</h1>
          <div class="row container-fluid">
            <a href="<?php echo base_url('admin/crudmenu') ?>"><button type="button" name="button" class="btn btn-primary">CRUD Menu</button></a>
          </div>
          <h2>Daftar Menu</h2>
          <div class="table-responsive" style="height:70vh;overflow-y:auto">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Nama Menu</th>
                  <th>Foto Menu</th>
                  <th>Deskripsi</th>
                  <th>Harga</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($menus as $menu): ?>
                  <tr>
                    <td><?php echo $menu['std_nama_menu'] ?></td>
                    <td><img src="<?php echo base_url('/resource/img/'.$menu['std_imgsrc']) ?>" alt="" style="width:200px"> </td>
                    <td><?php echo $menu['std_deskripsi'] ?></td>
                    <td><?php echo $menu['std_harga_menu'] ?></td>
                  </tr>
                <?php endforeach; ?>

              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>

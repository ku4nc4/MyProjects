<style media="screen">
  .tengah{
    text-align: center;
  }
</style>
<div class="container">
  <h1>All Bills</h1>
  <hr>
  <div class="row">
    <table class="table">
      <thead>
        <tr>
          <th>Bill Number</th>
          <th>Seat Number</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($bills as $bill): ?>
          <tr>
            <td><?php echo $bill['pk_id_trans_header'] ?></td>
            <td><?php echo $bill['fk_id_seat'] ?></td>
            <td><a href="<?php echo base_url("admin/printbill/".$bill['pk_id_trans_header']) ?>"><button type="button" name="button" class="btn btn-primary">Print</button></a></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

  </div>
</div>
<script type="text/javascript">
var request;
var old = "";

$(document).ready(function(){
  function ping(){
    request = $.ajax({
      url: "<?php echo base_url('admin/cashier') ?>",
      type: "post"
    });
    request.done(function(response){
      if (old == "") {
        old = response;
      } else if(old != response) {
        location.reload();
      }
    });

  }
  setInterval(function(){
    ping();
  },1000);
});
</script>

<style media="screen">
	.cropit-preview {
		/* You can specify preview size in CSS */
		width: 800px;
		height: 600px;
		border-style: solid;
		border-width: 2px;
	}
</style>
<div class="container">
	<?php echo $crud['output'] ?>
</div>

<script type="text/javascript">
	// In the demos I'm passing in an imageState option
	// so it renders an image by default:
	// $('#image-cropper').cropit({ imageState: { src: { imageSrc } } });

	// Exporting cropped image
</script>

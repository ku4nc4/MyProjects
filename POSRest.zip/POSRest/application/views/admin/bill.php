  <div class="container-fluid">
    <div class="row container-fluid">
    </div>
    <table class="table" style="width:300px;">
      <thead>
        <tr>
          <th colspan="4">POS RESTAURANT</th>
        </tr>
        <tr>
          <th colspan="2">No Bill : <?php echo $billdatas[0]['pk_id_trans_header'] ?></th>
          <th colspan="2">Table Num : <?php echo $billdatas[0]['fk_id_seat'] ?></th>
        </tr>
        <tr>
          <th>Item</th>
          <th>Qty</th>
          <th>Price</th>
          <th>Total Price</th>
        </tr>
      </thead>
      <tbody>
        <?php $totalharga = 0 ?>
        <?php foreach ($billdatas as $billdata): ?>
          <tr>
            <td><?php echo $billdata['std_nama_menu'] ?></td>
            <td><?php echo $billdata['std_qty'] ?></td>
            <td class="money"><?php echo $billdata['std_harga_menu'] ?></td>
            <td class="money"><?php echo $billdata['std_harga_menu']*$billdata['std_qty'] ?></td>
          </tr>
          <?php $totalharga += $billdata['std_harga_menu']*$billdata['std_qty'] ?>
        <?php endforeach; ?>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td class="money"><?php echo $totalharga ?></td>
        </tr>
        <tr>
          <td colspan="4" class="text-center">Please Come Again!</td>
        </tr>
      </tbody>
    </table>
    <div class="row">
      <button type="button" name="button" onclick="window.print();" class="btn btn-primary d-print-none mr-1 ml-2">Print</button>
      <a href="<?php echo base_url('admin/cancelprint/'.$billdatas[0]['pk_id_trans_header']) ?>" ><button type="button" name="button" class="btn btn-primary d-print-none mr-1">Cancel Print</button></a>
      <a href="<?php echo base_url('admin/cashier') ?>" ><button type="button" name="button" class="btn btn-primary d-print-none">Done Printing</button></a>
    </div>
  </div>

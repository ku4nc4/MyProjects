<div class="container">
	<div class="row">
		<div class="col-md-8" style="margin:0 auto;">
			<div class="card mb-5 mt-5">
				<div class="card-header">
					<h1>Admin Login</h1>
				</div>
			</div>
			<?php echo form_open('auth_login/admin'); ?>
			<div class="form-group">
				<label for="exampleInputEmail1">Email address</label>
				<input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" name="uname">
				<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
			</div>
			<div class="form-group">
				<label for="exampleInputPassword1">Password</label>
				<input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" name="pwd">
			</div>
			<div class="form-check">
				<label class="form-check-label">
          <input type="checkbox" class="form-check-input">
          Check me out
        </label>
			</div>
			<a href="<?php echo base_url('admin/register'); ?>"><button class="btn btn-default" type="button" style="float:right">Register</button></a>
			<button type="submit" class="btn btn-primary">Submit</button>
			<?php echo form_close(); ?>
		</div>
	</div>
</div>

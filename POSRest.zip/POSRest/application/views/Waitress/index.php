<style media="screen">
  .tengah{
    text-align: center;
  }
</style>
<div class="container-fluid">
  <h1>All Orders</h1>
  <hr>
  <div class="row">
<?php
$counter = 1;
foreach($order_list as $order){

 ?>
    <div class="col-md-4">
      <div class="card">
        <div class="card-header" style="background-color:">
          <h3>ORDER NUMBER <?php echo $counter?></h3>
        </div>
        <div class="card-block">
        <div class="container-fluid">
          <h4 class="card-title">Meja No <?php echo $order['fk_id_seat']?></h4>
            <table class="table table-striped">
              <thead>
                <th>Nama</th>
                <th>Jumlah</th>
                <th>Action</th>
              </thead>
              <tbody>
                <?php foreach ($this->Waitress_Model->getorderseat($order['fk_id_seat']) as $detailseat): ?>
                  <tr>
                    <td><?php echo $detailseat['std_nama_menu'] ?></td>
                    <td class="tengah"><?php echo $detailseat['std_qty'] ?></td>
                    <td><a href="<?php echo base_url('waitress/done/').$detailseat['pk_id_detail_kitchen'] ?>"><button type="button" name="button" class="btn btn-info" style="float:right;margin-bottom:10px;">Done</button></a></td>
                  </tr>

                <?php  endforeach; ?>

              </tbody>
            </table>
        </div>
        </div>
      </div>
    </div>
    <?php $counter++ ?>
    <?php
  }
     ?>

  </div>
</div>
<script type="text/javascript">
var request;
var old = "";

$(document).ready(function(){
  function ping(){
    request = $.ajax({
      url: "<?php echo base_url('waitress') ?>",
      type: "post"
    });
    request.done(function(response){
      if (old == "") {
        old = response;
      } else if(old != response) {
        location.reload();
      }
    });

  }
  setInterval(function(){
    ping();
  },1000);
});
</script>

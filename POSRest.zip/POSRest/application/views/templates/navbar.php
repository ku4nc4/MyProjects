<!-- Navbar Start here -->
<div class="container-fluid">
	<nav class="navbar navbar-dark bg-dark">
		<h1 class="navbar-brand mb-0">POS Restaurant</h1>
	</nav>
</div>
<!-- Navbar Ends here -->

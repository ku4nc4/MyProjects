<script src="<?php echo base_url('resource/js/jquery-3.2.1.min.js') ?>" charset="utf-8"></script>
<script src="<?php echo base_url('resource/js/popper.min.js') ?>" charset="utf-8"></script>
<script src="<?php echo base_url('resource/js/bootstrap.min.js') ?>" charset="utf-8"></script>
<script src="<?php echo base_url('resource/js/cleave.min.js') ?>" charset="utf-8"></script>
<script src="<?php echo base_url('resource/js/numeral.js') ?>" charset="utf-8"></script>
<?php if (isset($crud)): ?>
  <?php foreach ($crud['js_files'] as $file): ?>
    <script src="<?php echo $file ?>" charset="utf-8"></script>
  <?php endforeach; ?>
<?php endif; ?>

<link rel="stylesheet" href="<?php echo base_url('resource/css/bootstrap.min.css') ?>">
<?php if (isset($crud)): ?>
  <?php foreach ($crud['css_files'] as $file): ?>
    <link rel="stylesheet" href="<?php echo $file ?>">
  <?php endforeach; ?>
<?php endif; ?>

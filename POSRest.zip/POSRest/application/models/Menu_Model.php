<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu_Model extends CI_Model{
  function __construct(){
    parent::__construct();
    $this->load->database();
  }
  /*

  */
  public function add_menu($data){
    /*
    check query builder,
    ini sama kaya session, gw ga auto biar ga lupa.
    untuk load database dari config.php
    macam $conn = new msyqli($var,$var,$var,$var);
    */

    /*
      check query builder, tentang get specific data
    */
    $this->db->insert('ms_menu', $data);
    //return $result['staff_password'];
  }

  public function get_menu_type()
  {
    $this->db->select('*');
    $this->db->from('ms_menu_type');
    $query = $this->db->get();
    return $query->result_array();
  }
  public function get_menus()
  {
    $this->db->select('*');
    $this->db->from('ms_menu');
    $this->db->join('ms_menu_type','ms_menu_type.pk_id_menu_type = ms_menu.fk_id_menu_type');
    $query = $this->db->get();
    return $query->result_array();
  }
  public function addtotrans($head)
  {
    $this->load->library('session');
    if ($this->session->has_userdata('billnum')) {
      $insert_id = $this->session->userdata('billnum');
    } else {
      $this->db->insert('trans_header',$head);
      $insert_id = $this->db->insert_id();
      $this->session->set_userdata(array('billnum' => $insert_id));
    }
    $this->load->library('cart');
    $items = $this->cart->contents();
    foreach ($items as $item) {
      $detail = array(
        'fk_id_menu' => $item['id'],
        'std_qty' => $item['qty'],
        'fk_id_trans_header' => $insert_id
      );
      $this->db->insert('trans_detail',$detail);
      $this->db->insert('detail_kitchen', $detail);
    }
    $this->cart->destroy();
  }
  public function getbilldetail($headerid)
  {
    $this->db->select('*');
    $this->db->from('trans_detail');
    $this->db->join('trans_header','trans_detail.fk_id_trans_header = trans_header.pk_id_trans_header');
    $this->db->join('ms_menu','ms_menu.pk_id_menu = trans_detail.fk_id_menu');
    $this->db->where('fk_id_trans_header',$headerid);
    $res = $this->db->get();
    return $res->result_array();
  }
  public function promptpay($headerid)
  {
    $this->db->set('paid_status','1');
    $this->db->where('pk_id_trans_header',$headerid);
    $this->db->update('trans_header');
  }
  public function finishtrans($headerid)
  {
    $this->db->set('paid_status','2');
    $this->db->where('pk_id_trans_header',$headerid);
    $this->db->update('trans_header');
  }
}
 ?>

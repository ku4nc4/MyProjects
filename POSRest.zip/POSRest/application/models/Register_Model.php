<?php
defined('BASEPATH') or exit("no direct access");

class Register_Model extends CI_Model{
  function __construct(){
    parent::__construct();
  }
  public function insert_user_admin($data){
    $this->load->database();
    $this->db->insert('ms_staff', $data);
  }
}
 ?>

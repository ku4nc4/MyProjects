<?php
defined('BASEPATH') or exit();

class Kitchen_Model extends CI_Model{
  function __construct(){
    parent::__construct();
  }

  public function all_order(){
    $this->db->distinct();
    $this->db->select("fk_id_seat");
    $this->db->from('trans_header');
    $this->db->join('detail_kitchen','detail_kitchen.fk_id_trans_header = trans_header.pk_id_trans_header');
    $this->db->join('ms_menu','ms_menu.pk_id_menu = detail_kitchen.fk_id_menu');
    $this->db->where('done_status_kitchen','0');
    $result = $this->db->get();
    return $result->result_array();
  }
  public function getorderseat($seatid)
  {
    $this->db->select("std_nama_menu,std_qty,pk_id_detail_kitchen");
    $this->db->from('trans_header');
    $this->db->join('detail_kitchen','detail_kitchen.fk_id_trans_header = trans_header.pk_id_trans_header');
    $this->db->join('ms_menu','ms_menu.pk_id_menu = detail_kitchen.fk_id_menu');
    $this->db->where('done_status_kitchen','0');
    $this->db->where('fk_id_seat',$seatid);
    $result = $this->db->get();
    return $result->result_array();
  }

  public function update_pesanan($id){
    $this->db->where('pk_id_detail_kitchen', $id);
    $data = array(
        'done_status_kitchen' => 1
      );
    $this->db->update('detail_kitchen', $data);
  }
}
 ?>

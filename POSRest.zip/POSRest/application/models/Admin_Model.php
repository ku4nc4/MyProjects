<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_Model extends CI_Model{
  function __construct(){
    parent::__construct();
  }
  /*

  */
  public function get_staff($data){
    /*
    check query builder,
    ini sama kaya session, gw ga auto biar ga lupa.
    untuk load database dari config.php
    macam $conn = new msyqli($var,$var,$var,$var);
    */
    $this->load->database();
    /*
      check query builder, tentang get specific data
    */
    $sql = $this->db->get_where('ms_staff', array('staff_name'=>$data['staff_name']));
    $result = $sql->result_array();
    return $result;
    //return $result['staff_password'];
  }

  public function getBills()
  {
    $this->db->select("*");
    $this->db->from('trans_header');
    $this->db->where('paid_status',1);
    $result = $this->db->get();
    return $result->result_array();
  }

  public function getBillData($headerid)
  {
    $this->db->select('*');
    $this->db->from('trans_header');
    $this->db->where('pk_id_trans_header',$headerid);
    $this->db->join('trans_detail','trans_header.pk_id_trans_header = trans_detail.fk_id_trans_header');
    $this->db->join('ms_menu','ms_menu.pk_id_menu = trans_detail.fk_id_menu');
    $result = $this->db->get();
    return $result->result_array();
  }

  public function billFinalize($headerid)
  {
    $this->db->set('paid_status','2');
    $this->db->where('pk_id_trans_header',$headerid);
    $this->db->update('trans_header');
  }
  public function cancelPrint($headerid)
  {
    $this->db->set('paid_status','1');
    $this->db->where('pk_id_trans_header',$headerid);
    $this->db->update('trans_header');
  }
}
 ?>

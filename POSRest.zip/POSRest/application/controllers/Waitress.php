<?php
defined('BASEPATH') or exit();
class Waitress extends CI_Controller  {
  public function index(){
    $this->load->library('session');// load libary session
    $logged_in = $this->session->userdata('logged_in');//masukin session ke var logged_in
    if($logged_in == true){// check apakah logged_in == true
      $this->load->model('Waitress_Model');
      $data['title'] = 'Waiter Page';
      $data['css'] = $this->load->view('includes/css', NULL, TRUE);
      $data['js'] = $this->load->view("includes/js", NULL, TRUE);
      $data['username'] = $this->session->userdata('username');
      $data['order_list'] = $this->Waitress_Model->all_order();
      $this->load->view('templates/header', $data);
      $this->load->view('Waitress/index', $data);
      $this->load->view('templates/footer', $data);
    }else{//jika false maka redirect ke admin/login untuk melakukan login
      redirect('admin/login');
    }
  }
  public function done($id){
    $this->load->model('Waitress_Model');
    $this->Waitress_Model->update_pesanan($id);
    redirect('waitress');
  }
}
 ?>

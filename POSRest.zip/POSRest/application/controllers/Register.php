<?php
defined('BASEPATH') or exit("No Direct Access");

class Register extends CI_Controller{
  /*
  uname untuk tampung variabel post username dari (admin/register)
  pwd untuk tampung variabel post password dari (admin/register)
  password untuk tampung hasil hash dari password yang di input
  algoritma yang di pakai adalah PASSWORD_BCRYPT
  */
  public function admin(){
    $uname = $this->input->post('uname');
    $pwd = $this->input->post('pwd');
    $password = password_hash($pwd, PASSWORD_BCRYPT);
    /*
    load model register model untuk masukin data register ke database
    */
    $this->load->model('register_model');
    /*
    check CI Query Builder untuk insert data ke DB
    */
    $data = array(
      'staff_name' => $uname,
      'staff_password' => $password
    );
    /*
    oper data ke register_model, function insert_user_admin
    */
    $this->register_model->insert_user_admin($data);
    redirect('admin');
  }

  public function customer(){
    echo "page register customer";
  }

}
 ?>

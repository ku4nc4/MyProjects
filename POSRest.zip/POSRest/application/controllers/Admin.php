<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
* title = untuk title setiap webpage
* css untuk echo css bootstrap
* jquery untuk echo jquery bootstrap
* popper untuk echo popper bootstrap
* js untuk echo bootsrap js
* header untuk load page header (views/templates/header)
* admin/index adalah tampilan body
* templates/footer untuk tampilin footer (vies/templates/footer)
*
* @param type
* @return void
*/

class Admin extends CI_Controller{
  public function __construct()
  {
    parent::__construct();
  }
  // public function  index untuk default route (/admin)
  public function index(){
    $this->load->library('session');// load libary session
    $this->load->model('menu_model');
    $data['menus'] = $this->menu_model->get_menus();
    $logged_in = $this->session->userdata('logged_in');//masukin session ke var logged_in
    if($logged_in == true){// check apakah logged_in == true
      $data['title'] = 'Admin Page';
      $data['css'] = $this->load->view('includes/css', NULL, TRUE);
      $data['js'] = $this->load->view("includes/js", NULL, TRUE);
      $data['username'] = $this->session->userdata('username');
      $this->load->view('templates/header', $data);
      $this->load->view('admin/index', $data);
      $this->load->view('templates/footer', $data);
    }else{//jika false maka redirect ke admin/login untuk melakukan login
      redirect('admin/login');
    }

  }
  // route untuk login page (/admin/login)
  public function login(){
    $this->load->library('session');
    $logged_in = $this->session->userdata('logged_in');//masukin session ke var logged_in
    if($logged_in == false){
      $this->load->helper('form');//load helper form
      $data['title'] = 'Admin Login Page';
      $data['css'] = $this->load->view('includes/css', NULL, TRUE);
      $data['js'] = $this->load->view("includes/js", NULL, TRUE);
      $this->load->view('templates/header', $data);
      $this->load->view('templates/navbar',$data);
      $this->load->view('admin/login', $data);
      $this->load->view('templates/footer',$data);
    }else{
      redirect('admin');
    }
  }
  //route untuk register oage admin (/admin/register)
  public function register(){
    $this->load->helper('form');//load helper form
    $data['title'] = 'Admin Register Page';
    $data['css'] = $this->load->view('includes/css', NULL, TRUE);
    $data['js'] = $this->load->view("includes/js", NULL, TRUE);
    // $this->load->view('templates/header', $data);
    $this->load->view('templates/navbar',$data);
    $this->load->view('admin/register', $data);
    $this->load->view('templates/footer',$data);
  }
  //route untuk logout admin
  public function logout(){
    $this->load->library('session');
    $array_items = array('uname', 'id','logged_in');
    $this->session->unset_userdata($array_items);
    redirect('admin');
  }
  public function crudmenu()
  {
    $this->load->library('session');
    $this->load->library('grocery_CRUD');
    $crud = new grocery_CRUD();
    $crud->set_table("ms_menu");
    $crud->set_field_upload('std_imgsrc','resource/img');
    $crud->set_theme('datatables');
    $crud->set_relation('fk_id_menu_type','ms_menu_type','std_nama_menu_type');
    // $this->grocery_crud->columns('std_nama_menu','fk_id_menu_type','std_imgsrc','std_deskripsi','std_harga_menu');
    $output = $crud->render();
    $data['crud'] = get_object_vars($output);
    $logged_in = $this->session->userdata('logged_in');
    if($logged_in == true){
      $this->load->helper('form');//load helper form
      $data['title'] = 'CRUD Menu Page';
      $data['css'] = $this->load->view('includes/css', $data, TRUE);
      $data['js'] = $this->load->view("includes/js", $data, TRUE);
      $this->load->view('templates/header', $data);
      $this->load->view('templates/navbar',$data);
      $this->load->view('admin/crudmenu', $data);
      $this->load->view('templates/footer',$data);
    }else{
      redirect('admin');
    }
  }

  public function cashier()
  {
    $this->load->model('admin_model');
    $this->load->library('session');// load libary session
    $data['title'] = 'Cashier Page';
    $data['css'] = $this->load->view('includes/css', NULL, TRUE);
    $data['js'] = $this->load->view("includes/js", NULL, TRUE);
    $data['username'] = $this->session->userdata('username');
    $data['bills'] = $this->admin_model->getBills();
    $logged_in = $this->session->userdata('logged_in');//masukin session ke var logged_in
    if($logged_in == true){// check apakah logged_in == true
      $this->load->view('templates/header', $data);
      $this->load->view('admin/cashier', $data);
      $this->load->view('templates/footer', $data);
    }else{//jika false maka redirect ke admin/login untuk melakukan login
      redirect('admin/login');
    }
  }

  public function printbill($billid)
  {
    $this->load->model('admin_model');
    $this->load->library('session');// load libary session
    $data['title'] = 'Bill no '.$billid;
    $data['css'] = $this->load->view('includes/css', NULL, TRUE);
    $data['js'] = $this->load->view("includes/js", NULL, TRUE);
    $data['username'] = $this->session->userdata('username');
    $data['billdatas'] = $this->admin_model->getBillData($billid);
    $this->admin_model->billFinalize($billid);
    $logged_in = $this->session->userdata('logged_in');//masukin session ke var logged_in
    if($logged_in == true){// check apakah logged_in == true
      $this->load->view('templates/header', $data);
      $this->load->view('admin/bill', $data);
      $this->load->view('templates/footer', $data);
      $this->load->view('utilities/numberformat');
    }else{//jika false maka redirect ke admin/login untuk melakukan login
      redirect('admin/login');
    }
  }
  public function cancelprint($billid)
  {
    $this->load->model('admin_model');
    $this->admin_model->cancelPrint($billid);
    redirect('admin/cashier');
  }
}

?>

<?php
defined('BASEPATH') OR exit("Not Allowed");

class Order extends CI_Controller{

  public function index(){
      $data['title'] = 'Order Page';
      $data['css'] = $this->load->view('includes/css', NULL, TRUE);
      $data['js'] = $this->load->view("includes/js", NULL, TRUE);
      $this->load->view('templates/header', $data);
      $this->load->view('kitchen/index', $data);
      $this->load->view('templates/footer', $data);
  }
  public function processed(){

  }
  public function done(){

  }
}
 ?>

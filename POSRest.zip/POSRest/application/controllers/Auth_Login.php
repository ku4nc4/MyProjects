<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 	 * Controller untuk check apakah yang login dari admin page atau user page
   * apabila dari admin page maka masuk ke function Admin
   * apabila dari user page masuk ke function user
 	 *
 	 * @param type
 	 * @return void
	 */


class Auth_Login extends CI_Controller{

  public function admin(){
    /*
    variable uname untuk menampung post dari page admin/login
    variable pwd untuk menampung post dari page admin/login
    $this->input->post sama kek $_POST['uname']
    */
    $uname = $this->input->post('uname', true);
    $pwd = $this->input->post('pwd', true);
    /*
      load model Admin_Model.php untuk interaksi dengan database
      sementara gw bikin manual, yaitu harus terus inisialisasi this load model
      biar belajar, karena kalo dibikin auto di config.php nanti lupa.
    */
    $this->load->model('admin_model');
    /*
    liat query buildernya laravel tentang get_where
    ini kirim data ke Admin_Model, panggil function get_staff dari admin_model
    */
    $data = array(
      'staff_name' => $uname
    );
    /*
    oper $data ke model admin_model function get_staff dimana nanti
    hasil returnya di tampung di $result
    */
    $result = $this->admin_model->get_staff($data);
    //foreach biasa
    foreach($result as $row){
      $id = $row['id'];
      $uname = $row['staff_name'];
      $pass = $row['staff_password'];
    }
    /*
    melakukan check untuk password. hashing menggunakan PASSWORD_BCRYPT
    untuk hashing password pake function password_hash($var, PASSWORD_BCRYPT)
    optional menggunakan salt, cuman disini gw ga pake karena males
    untuk password_verify, digunakan untuk check password yang tadi di hashing
    password_verify($var1, $var2) var1 untuk password input, var2 untuk password
    dari database
    */
    if(password_verify($pwd,$pass)){
      /*
      load libary session
      agar bisa pake $_SESSION[];
      terus ini yang this load library sama kaya session_start() nya php
      */
      $this->load->library('session');
      /*
      ini untuk inisialisasi setiap session dengan nama yang dikiri, dengan
      value yang di kanan.
      $_SESSION['username'] = $uname;
      $_SESSION['id'] = $id;
      $_SESSION['logged_in'] = TRUE;
      */
      $login_data = array(
        'username'  => $uname,
        'id'     => $id,
        'logged_in' => TRUE
      );
      $this->session->set_userdata($login_data);
      redirect('admin');
    }else{
      redirect('admin');
    }

  }

  public function user(){

  }
}
 ?>

<?php
defined('BASEPATH') or exit('no direct access');

class Bill extends CI_Controller{
  public function close(){

  }
}
 ?>

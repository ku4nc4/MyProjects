<?php
defined('BASEPATH') or exit("NO DIRECT ACCESS");

class Menu extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $this->load->model('menu_model');
        $this->load->helper('url'); // Load URL Helper for base_url()
        $this->load->helper('html'); // Load HTML Helper for img()
        $this->load->helper('form');
        $this->load->library('cart');
        $data['menus'] = $this->menu_model->get_menus();
        $data['ip'] = $this->input->ip_address();
        $data['title'] = 'Menu Page';
        $data['css'] = $this->load->view('includes/css', NULL, TRUE);
        $data['js'] = $this->load->view("includes/js", NULL, TRUE);
        $cartdata['cartdata'] = $this->cart->contents();
        $this->load->view('menu/cart',$cartdata);
        $this->load->view('templates/header', $data);
        $this->load->view('utilities/numberformat');
        $this->load->view('menu/index');
        $this->load->view('templates/footer', $data);
    }

    public function checkout()
    {
        $this->load->helper('url'); // Load URL Helper for base_url()
        $this->load->helper('html'); // Load HTML Helper for img()
        $this->load->library('cart');
        $data['ip'] = $this->input->ip_address();
        $data['title'] = 'Checkout Page';
        $data['css'] = $this->load->view('includes/css', NULL, TRUE);
        $data['js'] = $this->load->view("includes/js", NULL, TRUE);
        $this->load->view('templates/header', $data);
        $this->load->view('utilities/numberformat');
        $cartdata['cartdata'] = $this->cart->contents();
        $this->load->view('menu/checkout',$cartdata);
        $this->load->view('templates/footer', $data);

    }
    public function bill()
    {
      $this->load->helper('url'); // Load URL Helper for base_url()
      $this->load->helper('html'); // Load HTML Helper for img()
      $this->load->library('session');
      $this->load->model('menu_model');
      $billdata['billitem'] = $this->menu_model->getbilldetail($this->session->userdata('billnum'));
      $data['ip'] = $this->input->ip_address();
      $data['title'] = 'Bill Overview';
      $data['css'] = $this->load->view('includes/css', NULL, TRUE);
      $data['js'] = $this->load->view("includes/js", NULL, TRUE);
      $this->load->view('templates/header', $data);
      $this->load->view('utilities/numberformat');
      $this->load->view('menu/bill',$billdata);
      $this->load->view('templates/footer', $data);
    }
    public function addcart()
    {
      $this->load->library('cart');
      $menuid = $this->input->post('menuid');
      $menuname = $this->input->post('menuname');
      $price = $this->input->post('price');
      echo $menuid;
      $qty = $this->input->post('qty');
      if ($qty == 0) {
        redirect('menu');
      }
      echo $qty;
      $data = array(
        'id' => $menuid,
        'qty' => $qty,
        'price' => $price,
        'name' => $menuname
      );
      $this->cart->insert($data) or die($this->cart->error);
      redirect('menu');
    }

    public function emptycart()
    {
      $this->load->library('cart');
      $this->cart->destroy();
      redirect('menu');
    }
    public function deletecartid($id)
    {
      $this->load->library('cart');
      $data = array(
        array(
          'rowid' => $id,
          'qty' => 0
        )
      );
      $this->cart->update($data);
      redirect('menu');
    }
    public function sendtokitchen()
    {
      $this->load->helper('url'); // Load URL Helper for base_url()
      $this->load->helper('html'); // Load HTML Helper for img()
      $this->load->library('cart');
      $this->load->model('menu_model');
      $ip = $this->input->ip_address();
      $iparr = explode('.',$ip);
      $iparr = end($iparr);
      $iparr = explode(':',$iparr);
      $seatid = end($iparr);
      $items = $this->cart->contents();
      // var_dump($items);
      $iduser = 1; // 0 untuk guest
      $header = array(
        'fk_id_user' => $iduser,
        'fk_id_seat' => $seatid
      );
      $this->menu_model->addtotrans($header);
      redirect('menu');
    }
    public function paybills()
    {
      $this->load->helper('url'); // Load URL Helper for base_url()
      $this->load->helper('html'); // Load HTML Helper for img()
      $this->load->library('session');
      $this->load->model('menu_model');
      if ($this->session->userdata('paying')=='true') {
        echo "Please wait for the bill to be printed and brought to you";
        ?><a href="<?php echo base_url('menu/destroysession') ?>"><button type="button" name="button" style="visibility:hidden">Secret Button</button></a>  <?php
      } else {
        $this->menu_model->promptpay($this->session->userdata('billnum'));
        $this->session->set_userdata('paying','true');
        redirect('menu/paybills');
      }
    }
    public function destroysession()
    {
      $this->load->library('session');
      $this->session->sess_destroy();
      redirect('menu');
    }
}

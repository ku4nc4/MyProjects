<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/reset.css'); ?> ">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/main.css'); ?> ">
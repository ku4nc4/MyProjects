<script type="text/javascript" src="<?php echo base_url('/assets/js/jquery.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('/assets/js/main.js');?>"></script>